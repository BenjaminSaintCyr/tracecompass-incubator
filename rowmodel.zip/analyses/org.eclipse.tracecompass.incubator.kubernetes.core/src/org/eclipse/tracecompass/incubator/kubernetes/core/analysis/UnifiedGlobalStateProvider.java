package org.eclipse.tracecompass.incubator.kubernetes.core.analysis;

import java.util.HashMap;
import java.util.Map;
import java.util.StringJoiner;

import org.eclipse.jdt.annotation.NonNull;
import org.eclipse.tracecompass.statesystem.core.ITmfStateSystemBuilder;
import org.eclipse.tracecompass.tmf.core.event.ITmfEvent;
import org.eclipse.tracecompass.tmf.core.event.ITmfEventField;
import org.eclipse.tracecompass.tmf.core.statesystem.AbstractTmfStateProvider;
import org.eclipse.tracecompass.tmf.core.statesystem.ITmfStateProvider;
import org.eclipse.tracecompass.tmf.core.trace.ITmfTrace;

public class UnifiedGlobalStateProvider extends AbstractTmfStateProvider {

    private static final String ID = "org.eclipse.tracecompass.incubator.kubernetes.core.stateprovider.interval"; //$NON-NLS-1$
    private static final int VERSION = 1;
    private static final String START_SPAN = "start_span"; //$NON-NLS-1$
    // private static final String END_SPAN = "end_span"; //$NON-NLS-1$

    private final Map<String, Integer> spanToQuark;


    public UnifiedGlobalStateProvider(@NonNull ITmfTrace trace) {
        super(trace, ID);
        spanToQuark = new HashMap<>();
    }

    @Override
    public int getVersion() {
        return VERSION;
    }

    @Override
    public ITmfStateProvider getNewInstance() {
        return new UnifiedGlobalStateProvider(getTrace());
    }

    private static String getEventName(String ctfEventName) {
        @NonNull String[] ctfNames =  ctfEventName.split(":");
        if (ctfNames.length != 2 || !ctfNames[0].equals("k8s_ust")) {
            return "";
        }
        return ctfNames[1];
    }

    private int getOrDefaultQuark(ITmfStateSystemBuilder ssb, String processName) {
        int processQuark;
        if (spanToQuark.containsKey(processName)) {
            processQuark = spanToQuark.getOrDefault(processName, 0); // TODO better default
        } else {
            processQuark = ssb.getQuarkAbsoluteAndAdd(processName);
            spanToQuark.put(processName, processQuark);
        }
        return processQuark;
    }

    private int getOrDefaultRelativeQuark(ITmfStateSystemBuilder ssb, int relativeQuark, String processName) {
        int processQuark;
        if (spanToQuark.containsKey(processName)) {
            processQuark = spanToQuark.getOrDefault(processName, 0); // TODO better default
        } else {
            processQuark = ssb.getQuarkRelativeAndAdd(relativeQuark, processName);
            spanToQuark.put(processName, processQuark);
        }
        return processQuark;
    }

    @Override
    protected void eventHandle(ITmfEvent event) {
        try {

        ITmfEventField content = event.getContent();
        if (content == null) {
            return;
        }

        ITmfStateSystemBuilder ssb = getStateSystemBuilder();
        if (ssb == null) {
            return;
        }

        String eventName = getEventName(event.getName());
        if (eventName.isEmpty()) {
            return;
        }

        long timestamp = event.getTimestamp().toNanos();


        StringJoiner quarkNameBuilder = new StringJoiner("/");

        String processName = event.getContent().getFieldValue(String.class, "context._procname");
        int processQuark = getOrDefaultQuark(ssb, processName);

        String vtid = event.getContent().getFieldValue(String.class, "context._vtid");
        quarkNameBuilder.add(processName).add(vtid);
        int threadQuark = getOrDefaultRelativeQuark(ssb, processQuark, quarkNameBuilder.toString());

        String spanId = content.getFieldValue(String.class, "span_id");
        // TODO add parent to ids
        // String parentId = content.getFieldValue(String.class, "parent_span_id");
        quarkNameBuilder.add(spanId).add(eventName);
        if (eventName.equals(START_SPAN)) {
            String opName = event.getContent().getFieldValue(String.class, "op_name");
            quarkNameBuilder.add(opName);
            String quarkName = quarkNameBuilder.toString();
            ssb.modifyAttribute(timestamp, quarkName, threadQuark);
        } else {
            ssb.modifyAttribute(timestamp, null, threadQuark);
        }


//        int spanQuark = ssb.getQuarkRelativeAndAdd(threadQuark, quarkName);

//        String name = String.valueOf(TmfTraceUtils.resolveAspectOfNameForEvent(event.getTrace(), "Name", event)); //$NON-NLS-1$
//        ssb.modifyAttribute(timestamp, name, spanQuark);
//
//        if (spanId != null) {
//            spanToQuark.put(quarkName, spanQuark);
//        }

  } catch (Exception e){
return;
      // Deal with e as you please.
      //e may be any type of exception at all.

  }
    }

}
